package com.sotigram.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class SotigramSession(val accessToken: String, val userId: String)
data class SotigramProfile(
    val id: String,
    val username: String,
    val displayName: String,
    val bio: String,
    val collectionNumber: String?,
    val verified: Boolean
)
data class SotigramChat(
    val id: String,
    val title: String,
    val subtitle: String,
    val otherUserId: String,
    val lastMessage: String,
    val updatedAt: String
)
data class SotigramMessage(val id: String, val senderId: String, val body: String, val createdAt: String)

object SupabaseApi {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()
    private val jsonType = "application/json; charset=utf-8".toMediaType()
    private const val URL = BuildConfig.SUPABASE_URL
    private const val KEY = BuildConfig.SUPABASE_KEY

    private fun syntheticEmail(username: String) = username.lowercase() + "@users.sotigram.invalid"

    suspend fun register(username: String, password: String): SotigramSession = withContext(Dispatchers.IO) {
        validateCredentials(username, password)
        val payload = JSONObject()
            .put("email", syntheticEmail(username))
            .put("password", password)
            .put("data", JSONObject().put("username", username).put("display_name", username))
        val result = post("/auth/v1/signup", payload)
        val token = result.optString("access_token")
        val user = result.optJSONObject("user")
        if (token.isBlank() || user == null) {
            throw IOException("Регистрация создана, но сервер не выдал сессию. Проверь подтверждение email в настройках Supabase Auth.")
        }
        SotigramSession(token, user.getString("id"))
    }

    suspend fun login(username: String, password: String): SotigramSession = withContext(Dispatchers.IO) {
        require(username.matches(Regex("[A-Za-z0-9_]{3,32}"))) { "Некорректное имя пользователя." }
        val result = post("/auth/v1/token?grant_type=password", JSONObject()
            .put("email", syntheticEmail(username)).put("password", password))
        val token = result.optString("access_token")
        val userId = result.optJSONObject("user")?.optString("id").orEmpty()
        if (token.isBlank() || userId.isBlank()) throw IOException("Не удалось получить сессию.")
        SotigramSession(token, userId)
    }

    suspend fun profile(token: String, userId: String): SotigramProfile = withContext(Dispatchers.IO) {
        val rows = getArray("/rest/v1/profiles?id=eq.$userId&select=id,username,display_name,bio,collection_number,is_verified", token)
        if (rows.length() == 0) throw IOException("Профиль не найден. Включи trigger регистрации в базе или повтори регистрацию.")
        rows.getJSONObject(0).toProfile()
    }

    suspend fun walletBalance(token: String, userId: String): Long = withContext(Dispatchers.IO) {
        val rows = getArray("/rest/v1/sotigram_wallets?user_id=eq.$userId&select=balance", token)
        rows.optJSONObject(0)?.optLong("balance", 0L) ?: 0L
    }

    suspend fun users(token: String, currentUserId: String): List<SotigramProfile> = withContext(Dispatchers.IO) {
        val rows = getArray("/rest/v1/profiles?id=neq.$currentUserId&select=id,username,display_name,bio,collection_number,is_verified&order=username.asc&limit=100", token)
        (0 until rows.length()).map { rows.getJSONObject(it).toProfile() }
    }

    suspend fun chats(token: String, currentUserId: String): List<SotigramChat> = withContext(Dispatchers.IO) {
        val memberships = getArray("/rest/v1/conversation_members?user_id=eq.$currentUserId&select=conversation_id", token)
        val result = mutableListOf<SotigramChat>()
        for (i in 0 until memberships.length()) {
            val conversationId = memberships.getJSONObject(i).getString("conversation_id")
            val convs = getArray("/rest/v1/conversations?id=eq.$conversationId&select=id,title,kind,updated_at", token)
            if (convs.length() == 0) continue
            val conv = convs.getJSONObject(0)
            val members = getArray("/rest/v1/conversation_members?conversation_id=eq.$conversationId&user_id=neq.$currentUserId&select=user_id", token)
            val otherId = if (members.length() > 0) members.getJSONObject(0).optString("user_id") else ""
            val person = if (otherId.isNotBlank()) getArray("/rest/v1/profiles?id=eq.$otherId&select=username,display_name", token).optJSONObject(0) else null
            val latest = getArray("/rest/v1/messages?conversation_id=eq.$conversationId&select=body,created_at&order=created_at.desc&limit=1", token).optJSONObject(0)
            result.add(SotigramChat(
                id = conversationId,
                title = person?.optString("display_name")?.takeIf { !it.isNullOrBlank() } ?: conv.optString("title", "Чат"),
                subtitle = person?.optString("username")?.let { "@$it" } ?: "Sotigram",
                otherUserId = otherId,
                lastMessage = latest?.optString("body") ?: "Начните общение",
                updatedAt = conv.optString("updated_at")
            ))
        }
        result.sortedByDescending { it.updatedAt }
    }

    suspend fun messages(token: String, conversationId: String): List<SotigramMessage> = withContext(Dispatchers.IO) {
        val rows = getArray("/rest/v1/messages?conversation_id=eq.$conversationId&select=id,sender_id,body,created_at&deleted_at=is.null&order=created_at.asc&limit=300", token)
        (0 until rows.length()).map {
            val o = rows.getJSONObject(it)
            SotigramMessage(o.getString("id"), o.getString("sender_id"), o.getString("body"), o.getString("created_at"))
        }
    }

    suspend fun openDirectChat(token: String, currentUserId: String, otherUserId: String, displayTitle: String): String = withContext(Dispatchers.IO) {
        val existingMemberships = getArray("/rest/v1/conversation_members?user_id=eq.$currentUserId&select=conversation_id", token)
        for (i in 0 until existingMemberships.length()) {
            val id = existingMemberships.getJSONObject(i).getString("conversation_id")
            val kind = getArray("/rest/v1/conversations?id=eq.$id&kind=eq.direct&select=id", token)
            if (kind.length() == 0) continue
            val other = getArray("/rest/v1/conversation_members?conversation_id=eq.$id&user_id=eq.$otherUserId&select=user_id", token)
            if (other.length() > 0) return@withContext id
        }
        val created = postArray("/rest/v1/conversations", JSONObject().put("kind", "direct").put("title", displayTitle).put("created_by", currentUserId), token)
        val conversationId = created.optJSONObject(0)?.optString("id") ?: throw IOException("Не удалось создать чат.")
        postNoContent("/rest/v1/conversation_members", JSONArray()
            .put(JSONObject().put("conversation_id", conversationId).put("user_id", currentUserId).put("member_role", "member"))
            .put(JSONObject().put("conversation_id", conversationId).put("user_id", otherUserId).put("member_role", "member")), token)
        conversationId
    }

    suspend fun sendMessage(token: String, conversationId: String, senderId: String, body: String) = withContext(Dispatchers.IO) {
        val clean = body.trim()
        require(clean.isNotEmpty() && clean.length <= 4000) { "Сообщение должно быть от 1 до 4000 символов." }
        postNoContent("/rest/v1/messages", JSONObject()
            .put("conversation_id", conversationId).put("sender_id", senderId).put("body", clean), token)
    }

    private fun validateCredentials(username: String, password: String) {
        require(username.matches(Regex("[A-Za-z0-9_]{3,32}"))) { "Имя: 3–32 символа, латиница, цифры и _." }
        require(password.length >= 10) { "Пароль должен содержать не менее 10 символов." }
    }

    private fun JSONObject.toProfile() = SotigramProfile(
        id = getString("id"), username = getString("username"),
        displayName = optString("display_name").ifBlank { getString("username") },
        bio = optString("bio"), collectionNumber = optString("collection_number").takeIf { it.isNotBlank() && it != "null" },
        verified = optBoolean("is_verified")
    )

    private fun post(path: String, body: JSONObject): JSONObject = JSONObject(request(path, body.toString(), "POST", null))
    private fun postArray(path: String, body: JSONObject, token: String): JSONArray = JSONArray(request(path, body.toString(), "POST", token, true))
    private fun postNoContent(path: String, body: Any, token: String) {
        request(path, body.toString(), "POST", token, true)
    }
    private fun getArray(path: String, token: String): JSONArray = JSONArray(request(path, null, "GET", token))

    private fun request(path: String, body: String?, method: String, token: String?, preferRepresentation: Boolean = false): String {
        val builder = Request.Builder().url(URL + path).addHeader("apikey", KEY)
            .addHeader("Accept", "application/json")
        if (token != null) builder.addHeader("Authorization", "Bearer $token")
        if (preferRepresentation) builder.addHeader("Prefer", "return=representation")
        if (body != null) builder.addHeader("Content-Type", "application/json")
        when (method) {
            "POST" -> builder.post(body!!.toRequestBody(jsonType))
            "GET" -> builder.get()
        }
        client.newCall(builder.build()).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail = runCatching {
                    val o = JSONObject(text)
                    o.optString("message").ifBlank { o.optString("msg").ifBlank { o.optString("hint") } }
                }.getOrNull()
                throw IOException(detail?.takeIf { it.isNotBlank() } ?: "Ошибка сервера (${response.code}).")
            }
            return text
        }
    }
}
