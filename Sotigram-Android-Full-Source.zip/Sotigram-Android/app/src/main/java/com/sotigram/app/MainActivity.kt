package com.sotigram.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val TgBlue = Color(0xFF3390EC)
private val TgBlueDark = Color(0xFF2481D7)
private val Page = Color(0xFFF4F6F8)
private val Ink = Color(0xFF17212B)
private val Muted = Color(0xFF8A99A8)
private val Divider = Color(0xFFE9EDF1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SotigramApp() }
    }
}

@Composable
fun SotigramApp() {
    val scope = rememberCoroutineScope()
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var register by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var session by remember { mutableStateOf<SotigramSession?>(null) }
    var profile by remember { mutableStateOf<SotigramProfile?>(null) }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = TgBlue, onPrimary = Color.White, background = Page,
        surface = Color.White, onSurface = Ink, onBackground = Ink
    )) {
        Surface(Modifier.fillMaxSize(), color = Page) {
            if (session == null) {
                AuthScreen(
                    username = username, onUsername = { username = it },
                    password = password, onPassword = { password = it },
                    register = register, onToggle = { register = !register; error = null },
                    busy = busy, error = error,
                    onSubmit = {
                        busy = true; error = null
                        scope.launch {
                            runCatching {
                                if (register) SupabaseApi.register(username.trim(), password)
                                else SupabaseApi.login(username.trim(), password)
                            }.onSuccess { s ->
                                session = s
                                runCatching { SupabaseApi.profile(s.accessToken, s.userId) }
                                    .onSuccess { profile = it }
                                    .onFailure { error = it.message }
                            }.onFailure { error = it.message ?: "Не удалось выполнить запрос." }
                            busy = false
                        }
                    }
                )
            } else {
                MessengerShell(
                    session = session!!,
                    profile = profile,
                    onProfile = { profile = it },
                    onLogout = { session = null; profile = null; password = ""; error = null }
                )
            }
        }
    }
}

@Composable
private fun AuthScreen(
    username: String, onUsername: (String) -> Unit,
    password: String, onPassword: (String) -> Unit,
    register: Boolean, onToggle: () -> Unit,
    busy: Boolean, error: String?, onSubmit: () -> Unit
) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFEAF5FC), Page, Color.White)))) {
        Column(
            Modifier.fillMaxWidth().align(Alignment.Center).padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.size(92.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF54B8F5), TgBlueDark))), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Send, null, tint = Color.White, modifier = Modifier.size(44.dp))
            }
            Spacer(Modifier.height(18.dp))
            Text("Sotigram", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text("Общение без границ", fontSize = 15.sp, color = Muted)
            Spacer(Modifier.height(34.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Color.White).padding(20.dp)) {
                Text(if (register) "Создать аккаунт" else "С возвращением", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text(if (register) "Твой новый профиль в Sotigram" else "Войди, чтобы открыть свои чаты", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(22.dp))
                AuthField(username, onUsername, "Имя пользователя", "@", false)
                Spacer(Modifier.height(12.dp))
                AuthField(password, onPassword, "Пароль", "●", true)
                Spacer(Modifier.height(18.dp))
                Button(onClick = onSubmit, enabled = !busy, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(15.dp)) {
                    if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                    else Text(if (register) "Зарегистрироваться" else "Войти", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                }
                TextButton(onClick = onToggle, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                    Text(if (register) "Уже есть аккаунт? Войти" else "Нет аккаунта? Создать", color = TgBlue)
                }
                error?.let { Text(it, color = Color(0xFFD34B4B), fontSize = 12.sp) }
            }
            Spacer(Modifier.height(18.dp))
            Text("Ваши сообщения защищены настройками доступа аккаунта", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun AuthField(value: String, onValue: (String) -> Unit, label: String, prefix: String, secret: Boolean) {
    Column {
        Text(label, color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Page).padding(horizontal = 14.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(prefix, color = TgBlue, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(10.dp))
            if (secret) {
                BasicTextField(value, onValue, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation(), textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontSize = 15.sp))
            } else {
                BasicTextField(value, { onValue(it.removePrefix("@").filter { c -> c.isLetterOrDigit() || c == '_' }.take(32)) }, modifier = Modifier.fillMaxWidth(), singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontSize = 15.sp), decorationBox = { inner -> if (value.isEmpty()) Text("Например, Razrab", color = Color(0xFFB1BAC3)); inner() })
            }
        }
    }
}

@Composable
private fun MessengerShell(
    session: SotigramSession,
    profile: SotigramProfile?,
    onProfile: (SotigramProfile) -> Unit,
    onLogout: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var chats by remember { mutableStateOf<List<SotigramChat>>(emptyList()) }
    var contacts by remember { mutableStateOf<List<SotigramProfile>>(emptyList()) }
    var starsBalance by remember { mutableLongStateOf(0L) }
    var selectedChat by remember { mutableStateOf<SotigramChat?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var search by remember { mutableStateOf("") }

    fun refresh() {
        loading = true; error = null
        scope.launch {
            runCatching {
                val freshChats = SupabaseApi.chats(session.accessToken, session.userId)
                val freshContacts = SupabaseApi.users(session.accessToken, session.userId)
                val freshBalance = SupabaseApi.walletBalance(session.accessToken, session.userId)
                Triple(freshChats, freshContacts, freshBalance)
            }.onSuccess { (c, u, balance) -> chats = c; contacts = u; starsBalance = balance }
                .onFailure { error = it.message ?: "Ошибка загрузки" }
            loading = false
        }
    }
    LaunchedEffect(session.userId) { refresh() }

    if (selectedChat != null) {
        ConversationScreen(
            chat = selectedChat!!, session = session,
            onBack = { selectedChat = null; refresh() }
        )
        return
    }

    Scaffold(
        containerColor = Page,
        bottomBar = {
            NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {
                val items = listOf(Triple("Чаты", Icons.Default.Chat, 0), Triple("Контакты", Icons.Default.PeopleAlt, 1), Triple("Звонки", Icons.Default.Call, 2), Triple("Профиль", Icons.Default.Person, 3))
                items.forEach { (label, icon, index) ->
                    NavigationBarItem(selected = tab == index, onClick = { tab = index; search = "" }, icon = { Icon(icon, null) }, label = { Text(label, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = TgBlue, selectedTextColor = TgBlue, indicatorColor = Color(0xFFE7F3FC)))
                }
            }
        },
        floatingActionButton = {
            if (tab == 0 || tab == 1) FloatingActionButton(onClick = { tab = 1 }, containerColor = TgBlue, contentColor = Color.White, shape = CircleShape) { Icon(Icons.Default.Edit, "Новое сообщение") }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            when (tab) {
                0 -> {
                    TopHeader(title = "Sotigram", subtitle = "@${profile?.username ?: "…"}", action = { refresh() }, actionIcon = Icons.Default.Search)
                    SearchBar(value = search, onValue = { search = it }, placeholder = "Поиск")
                    StoriesStrip()
                    if (loading && chats.isEmpty()) LoadingState()
                    else if (chats.isEmpty()) EmptyState("Пока нет сообщений", "Найди человека в контактах и начни диалог", Icons.Default.ChatBubbleOutline)
                    else LazyColumn(Modifier.fillMaxSize()) {
                        items(chats.filter { it.title.contains(search, true) || it.subtitle.contains(search, true) }, key = { it.id }) { chat ->
                            ChatRow(chat) { selectedChat = chat }
                        }
                    }
                }
                1 -> {
                    TopHeader("Контакты", "Пользователи Sotigram", { refresh() }, Icons.Default.Refresh)
                    SearchBar(search, { search = it }, "Поиск по имени")
                    if (contacts.isEmpty() && !loading) EmptyState("Контактов пока нет", "Когда пользователи зарегистрируются, они появятся здесь", Icons.Default.PeopleAlt)
                    else LazyColumn(Modifier.fillMaxSize()) {
                        items(contacts.filter { it.username.contains(search, true) || it.displayName.contains(search, true) }, key = { it.id }) { user ->
                            ContactRow(user) {
                                loading = true
                                scope.launch {
                                    runCatching { SupabaseApi.openDirectChat(session.accessToken, session.userId, user.id, user.displayName) }
                                        .onSuccess { id -> selectedChat = SotigramChat(id, user.displayName, "@${user.username}", user.id, "Начните общение", "") }
                                        .onFailure { error = it.message }
                                    loading = false
                                }
                            }
                        }
                    }
                }
                2 -> {
                    TopHeader("Звонки", "Sotigram", { }, Icons.Default.Info)
                    EmptyState("Звонки появятся позже", "Голосовые и видеозвонки пока не подключены", Icons.Default.Call)
                }
                else -> ProfileScreen(profile, starsBalance, onLogout)
            }
            error?.let { Text(it, color = Color(0xFFD34B4B), fontSize = 12.sp, modifier = Modifier.padding(12.dp)) }
        }
    }
}

@Composable
private fun TopHeader(title: String, subtitle: String, action: () -> Unit, actionIcon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(Color(0xFFE5F3FC)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Send, null, tint = TgBlue, modifier = Modifier.size(21.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text(subtitle, fontSize = 12.sp, color = Muted)
        }
        IconButton(onClick = action) { Icon(actionIcon, null, tint = TgBlue) }
        IconButton(onClick = {}) { Icon(Icons.Default.MoreVert, null, tint = Muted) }
    }
}

@Composable
private fun SearchBar(value: String, onValue: (String) -> Unit, placeholder: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 9.dp).clip(RoundedCornerShape(13.dp)).background(Color(0xFFECEFF2)).padding(horizontal = 12.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Search, null, tint = Muted, modifier = Modifier.size(19.dp))
        Spacer(Modifier.width(8.dp))
        BasicTextField(value, onValue, modifier = Modifier.weight(1f), singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontSize = 14.sp), decorationBox = { inner -> if (value.isEmpty()) Text(placeholder, color = Muted); inner() })
        if (value.isNotEmpty()) Icon(Icons.Default.Close, null, tint = Muted, modifier = Modifier.clickable { onValue("") })
    }
}

@Composable
private fun StoriesStrip() {
    Row(Modifier.fillMaxWidth().background(Color.White).padding(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(66.dp)) {
            Box(Modifier.size(54.dp).border(2.dp, Color(0xFFD8E3EC), CircleShape).padding(4.dp).clip(CircleShape).background(Page), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Add, null, tint = TgBlue, modifier = Modifier.size(25.dp))
            }
            Spacer(Modifier.height(4.dp)); Text("Моя история", fontSize = 10.sp, color = Muted, maxLines = 1)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("Истории Sotigram", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text("Делись моментами с друзьями", color = Muted, fontSize = 11.sp)
        }
        Text("Скоро", color = TgBlue, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ChatRow(chat: SotigramChat, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color.White).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
        Avatar(chat.title)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(chat.title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text(chat.lastMessage, fontSize = 13.sp, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text("", fontSize = 10.sp, color = Muted)
            Spacer(Modifier.height(7.dp))
            Text(chat.subtitle, fontSize = 10.sp, color = Muted, maxLines = 1)
        }
    }
    Box(Modifier.fillMaxWidth().padding(start = 82.dp).height(0.7.dp).background(Divider))
}

@Composable
private fun ContactRow(user: SotigramProfile, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color.White).clickable(onClick = onClick).padding(horizontal = 15.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
        Avatar(user.displayName)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(user.displayName, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                if (user.verified) { Spacer(Modifier.width(5.dp)); Icon(Icons.Default.Verified, null, tint = TgBlue, modifier = Modifier.size(15.dp)) }
            }
            Text("@${user.username}", color = Muted, fontSize = 12.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Color(0xFFB4BEC7))
    }
}

@Composable
private fun Avatar(name: String, size: Int = 54) {
    val colors = listOf(Color(0xFF62A9E8), Color(0xFF57B6A2), Color(0xFFB28BD8), Color(0xFFE0A45F), Color(0xFFDF8194))
    val color = colors[(name.hashCode().and(Int.MAX_VALUE)) % colors.size]
    Box(Modifier.size(size.dp).clip(CircleShape).background(color), contentAlignment = Alignment.Center) {
        Text(name.firstOrNull()?.uppercase() ?: "S", color = Color.White, fontSize = (size / 2.5).sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun EmptyState(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Box(Modifier.fillMaxSize().background(Page), contentAlignment = Alignment.Center) {
        Column(Modifier.padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(82.dp).clip(CircleShape).background(Color(0xFFE3F2FC)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = TgBlue, modifier = Modifier.size(37.dp)) }
            Spacer(Modifier.height(17.dp)); Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp)); Text(subtitle, color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
        }
    }
}

@Composable
private fun LoadingState() { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = TgBlue) } }

@Composable
private fun ProfileScreen(profile: SotigramProfile?, starsBalance: Long, onLogout: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Page)) {
        TopHeader("Профиль", "Твой аккаунт Sotigram", {}, Icons.Default.Settings)
        Column(Modifier.fillMaxWidth().background(Color.White).padding(vertical = 25.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Avatar(profile?.displayName ?: "S", 86)
            Spacer(Modifier.height(12.dp))
            Text(profile?.displayName ?: "Sotigram user", fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text("@${profile?.username ?: "unknown"}", color = Muted, fontSize = 13.sp)
            if (profile?.verified == true) { Spacer(Modifier.height(5.dp)); Text("✓ Подтверждённый профиль", color = TgBlue, fontSize = 12.sp) }
        }
        Spacer(Modifier.height(10.dp))
        Column(Modifier.fillMaxWidth().background(Color.White).padding(17.dp)) {
            ProfileInfo("Коллекционный номер", profile?.collectionNumber ?: "Не назначен")
            HorizontalDivider(color = Divider)
            ProfileInfo("Sotigram Stars", "$starsBalance ★")
            HorizontalDivider(color = Divider)
            ProfileInfo("О себе", profile?.bio?.ifBlank { "Пока ничего не указано" } ?: "Загрузка…")
        }
        Spacer(Modifier.height(10.dp))
        TextButton(onClick = onLogout, modifier = Modifier.fillMaxWidth().background(Color.White)) { Icon(Icons.Default.Logout, null); Spacer(Modifier.width(8.dp)); Text("Выйти из аккаунта", color = Color(0xFFD94F4F)) }
    }
}

@Composable
private fun ProfileInfo(label: String, value: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 11.dp)) {
        Text(label, fontSize = 11.sp, color = Muted)
        Spacer(Modifier.height(4.dp)); Text(value, fontSize = 14.sp, color = Ink)
    }
}

@Composable
private fun ConversationScreen(chat: SotigramChat, session: SotigramSession, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var messages by remember { mutableStateOf<List<SotigramMessage>>(emptyList()) }
    var draft by remember { mutableStateOf("") }
    var sending by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val listState = rememberLazyListState()

    fun load() {
        scope.launch { runCatching { SupabaseApi.messages(session.accessToken, chat.id) }.onSuccess { messages = it }.onFailure { error = it.message } }
    }
    LaunchedEffect(chat.id) { load() }
    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex) }

    Column(Modifier.fillMaxSize().background(Color(0xFFE7EDF2))) {
        Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 7.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = TgBlue) }
            Avatar(chat.title, 42)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(chat.title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text(chat.subtitle, color = Muted, fontSize = 11.sp)
            }
            IconButton(onClick = { load() }) { Icon(Icons.Default.Refresh, null, tint = TgBlue) }
            IconButton(onClick = {}) { Icon(Icons.Default.MoreVert, null, tint = Muted) }
        }
        if (messages.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Начало диалога", color = Color(0xFF71808E), fontWeight = FontWeight.SemiBold)
                    Text("Отправь первое сообщение в Sotigram", color = Color(0xFF8A98A5), fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), state = listState, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                items(messages, key = { it.id }) { msg ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.senderId == session.userId) Arrangement.End else Arrangement.Start) {
                        Column(Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(17.dp)).background(if (msg.senderId == session.userId) Color(0xFFD9FDD3) else Color.White).padding(horizontal = 12.dp, vertical = 8.dp)) {
                            Text(msg.body, color = Ink, fontSize = 15.sp, lineHeight = 20.sp)
                            Text(msg.createdAt.take(16).replace("T", " "), color = Muted, fontSize = 9.sp, modifier = Modifier.align(Alignment.End))
                        }
                    }
                }
            }
        }
        error?.let { Text(it, color = Color(0xFFD34B4B), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 12.dp)) }
        Row(Modifier.fillMaxWidth().background(Color(0xFFF7F8FA)).padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = {}) { Icon(Icons.Default.AttachFile, null, tint = Muted) }
            Row(Modifier.weight(1f).clip(RoundedCornerShape(24.dp)).background(Color.White).padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(draft, { draft = it.take(4000) }, modifier = Modifier.weight(1f), textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontSize = 15.sp), decorationBox = { inner -> if (draft.isEmpty()) Text("Сообщение", color = Muted); inner() })
                Icon(Icons.Default.EmojiEmotions, null, tint = Muted, modifier = Modifier.size(21.dp))
            }
            Spacer(Modifier.width(5.dp))
            IconButton(onClick = {
                if (draft.isNotBlank() && !sending) {
                    val text = draft; draft = ""; sending = true
                    scope.launch {
                        runCatching { SupabaseApi.sendMessage(session.accessToken, chat.id, session.userId, text) }
                            .onSuccess { load() }
                            .onFailure { error = it.message; draft = text }
                        sending = false
                    }
                }
            }, enabled = draft.isNotBlank() && !sending) {
                Icon(Icons.Default.Send, null, tint = if (draft.isNotBlank()) TgBlue else Muted)
            }
        }
    }
}
