-- Applied to Supabase project tryhiueaukgahtonattf.
-- This patch assumes the baseline Sotigram tables already exist.

create unique index if not exists profiles_username_ci_unique
  on public.profiles (lower(username));

create schema if not exists app_private;
revoke all on schema app_private from public, anon, authenticated;
grant usage on schema app_private to authenticated;

create or replace function app_private.is_conversation_member(_conversation_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select auth.uid() is not null and exists (
    select 1 from public.conversation_members cm
    where cm.conversation_id = _conversation_id
      and cm.user_id = auth.uid()
  );
$$;
revoke all on function app_private.is_conversation_member(uuid) from public, anon;
grant execute on function app_private.is_conversation_member(uuid) to authenticated;

drop policy if exists "users read their own memberships" on public.conversation_members;
drop policy if exists "members read their own memberships" on public.conversation_members;
drop policy if exists "members read memberships in their conversations" on public.conversation_members;
create policy "members read memberships in their conversations"
  on public.conversation_members for select to authenticated
  using (app_private.is_conversation_member(conversation_id));

drop policy if exists "members read conversations they belong to" on public.conversations;
drop policy if exists "creators read conversations they created" on public.conversations;
drop policy if exists "members and creators read conversations" on public.conversations;
create policy "members and creators read conversations"
  on public.conversations for select to authenticated
  using (created_by = (select auth.uid()) or app_private.is_conversation_member(id));

drop policy if exists "users create conversations" on public.conversations;
create policy "users create conversations"
  on public.conversations for insert to authenticated
  with check (created_by = (select auth.uid()));

drop policy if exists "conversation creator adds members" on public.conversation_members;
create policy "conversation creator adds members"
  on public.conversation_members for insert to authenticated
  with check (
    exists (
      select 1 from public.conversations c
      where c.id = conversation_members.conversation_id
        and c.created_by = (select auth.uid())
    )
  );

drop policy if exists "members read messages in their conversations" on public.messages;
create policy "members read messages in their conversations"
  on public.messages for select to authenticated
  using (app_private.is_conversation_member(conversation_id));

drop policy if exists "members send messages as themselves" on public.messages;
create policy "members send messages as themselves"
  on public.messages for insert to authenticated
  with check (
    sender_id = (select auth.uid())
    and app_private.is_conversation_member(conversation_id)
  );

create or replace function app_private.handle_new_sotigram_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  chosen_username text;
  is_owner_bootstrap boolean;
begin
  chosen_username := coalesce(
    nullif(new.raw_user_meta_data ->> 'username', ''),
    split_part(new.email, '@', 1)
  );
  is_owner_bootstrap := coalesce((new.raw_app_meta_data ->> 'sotigram_owner_bootstrap')::boolean, false);

  if lower(chosen_username) = 'razrab' and not is_owner_bootstrap then
    raise exception 'This username is reserved.';
  end if;

  insert into public.profiles (id, username, display_name, bio, collection_number)
  values (
    new.id,
    chosen_username,
    coalesce(nullif(new.raw_user_meta_data ->> 'display_name', ''), chosen_username),
    '',
    case when is_owner_bootstrap then '+888888888888' else null end
  )
  on conflict (id) do nothing;

  insert into public.sotigram_wallets (user_id, balance)
  values (new.id, 0)
  on conflict (user_id) do nothing;

  if is_owner_bootstrap then
    insert into public.user_roles (user_id, role)
    values (new.id, 'owner')
    on conflict do nothing;
  end if;

  return new;
end;
$$;

 drop trigger if exists on_auth_user_created_sotigram on auth.users;
 create trigger on_auth_user_created_sotigram
   after insert on auth.users
   for each row execute function app_private.handle_new_sotigram_user();

-- Explicit Data API grants for the app's signed-in messaging flows.
grant usage on schema public to authenticated;
grant select, insert, update on public.profiles to authenticated;
grant select, insert on public.conversations to authenticated;
grant select, insert on public.conversation_members to authenticated;
grant select, insert, update on public.messages to authenticated;
