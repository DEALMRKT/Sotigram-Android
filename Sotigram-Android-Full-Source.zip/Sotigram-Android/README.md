# Sotigram — Android messenger

Native Android app built with Kotlin + Jetpack Compose. The visual direction follows the familiar modern Telegram Android pattern (compact blue header, search, story strip, chat list, bottom navigation, conversation bubbles) while keeping Sotigram branding and its own product identity.

## Implemented in this source

- Username + password registration/login through Supabase Auth (username mapped to a synthetic `.invalid` email).
- Supabase profile and wallet initialization trigger on account creation.
- Contacts directory backed by `profiles`.
- Direct conversations: create/open a conversation, load messages, send text messages, refresh conversation history.
- Profile screen with the reserved collectible number field and Sotigram Stars balance placeholder.
- Telegram-inspired UI: blue/white palette, chat rows, circular avatars, search, stories placeholder, bottom tabs and message composer.
- GitHub Actions workflow to build a debug APK.

## Supabase project

- Project ref: `tryhiueaukgahtonattf`
- URL: `https://tryhiueaukgahtonattf.supabase.co`
- Android contains only the Supabase **publishable** key. Never put a service-role or secret key in the APK.
- `supabase/migrations/20261124085000_messaging_and_owner_hardening.sql` records the messaging/RLS and owner-bootstrap hardening applied to the existing baseline schema.

## Important setup and security

1. In Supabase Auth, disable email confirmation for this username-only prototype, or replace the synthetic-email approach with a dedicated server-side username authentication service. The synthetic `.invalid` email cannot receive confirmation messages.
2. The username `Razrab` is reserved. Public sign-up cannot claim it. The auth trigger grants `owner` and assigns `+888888888888` only when a trusted administrator creates the Auth user with server-side `app_metadata.sotigram_owner_bootstrap = true`. Never set this flag from user-editable metadata or a public client. The owner account has not yet been created.
3. The password previously pasted into chat is not embedded in this project. Change it before production use.
4. This is a functional messaging foundation, not a complete Telegram replacement. Stories, voice/video calls, media upload, groups/channels UI, message editing/deletion, push notifications, multi-device session persistence, moderation dashboard, Stars purchases/ledger operations and realtime subscriptions still need implementation and testing.
5. Do not ship as production-ready until Auth settings, storage policies, realtime policies, owner bootstrap, rate limiting, abuse reporting and privacy behavior are reviewed.

## Build

Open this folder in Android Studio with JDK 17 and Android SDK 35, then run `gradle assembleDebug` (or `assembleDebug` from the Gradle task panel). The APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

The GitHub Actions workflow at `.github/workflows/android.yml` builds the same debug APK on pushes to `main` or manual workflow dispatch.
